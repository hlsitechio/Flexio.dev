import React, { createContext, useState, useContext, useEffect } from 'react';
import { lightTheme, darkTheme } from '../config/theme.config';

// ... rest of the file remains the same