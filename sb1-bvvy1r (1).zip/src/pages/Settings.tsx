import React from 'react';

const Settings: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>
      <p>This is the settings page. You can add various configuration options here.</p>
    </div>
  );
};

export default Settings;