import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    port: parseInt(process.env.PORT) || 3000,
    host: '0.0.0.0',
  },
  preview: {
    port: parseInt(process.env.PORT) || 3000,
    host: '0.0.0.0',
  },
  build: {
    outDir: 'dist',
    rollupOptions: {
      input: {
        main: path.resolve(__dirname, 'index.html'),
        server: path.resolve(__dirname, 'src/server/index.ts'),
      },
    },
  },
  define: {
    'import.meta.env.VITE_API_URL': JSON.stringify(process.env.VITE_API_URL),
    'import.meta.env.VITE_RAILWAY_TOKEN': JSON.stringify(process.env.VITE_RAILWAY_TOKEN),
    'import.meta.env.RAILWAY_PRIVATE_DOMAIN': JSON.stringify(process.env.RAILWAY_PRIVATE_DOMAIN),
    'import.meta.env.RAILWAY_PROJECT_NAME': JSON.stringify(process.env.RAILWAY_PROJECT_NAME),
    'import.meta.env.RAILWAY_ENVIRONMENT_NAME': JSON.stringify(process.env.RAILWAY_ENVIRONMENT_NAME),
    'import.meta.env.RAILWAY_SERVICE_NAME': JSON.stringify(process.env.RAILWAY_SERVICE_NAME),
    'import.meta.env.RAILWAY_PROJECT_ID': JSON.stringify(process.env.RAILWAY_PROJECT_ID),
    'import.meta.env.RAILWAY_ENVIRONMENT_ID': JSON.stringify(process.env.RAILWAY_ENVIRONMENT_ID),
    'import.meta.env.RAILWAY_SERVICE_ID': JSON.stringify(process.env.RAILWAY_SERVICE_ID),
  },
});