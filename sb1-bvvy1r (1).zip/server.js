import express from 'express';
import session from 'express-session';
import dotenv from 'dotenv';
import cors from 'cors';

dotenv.config();

const app = express();

app.use(cors({
  origin: 'http://localhost:3001', // Frontend URL
  credentials: true
}));

app.use(session({
  secret: process.env.SESSION_SECRET || 'fallback_secret_key_for_development',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: process.env.NODE_ENV === 'production' } // secure in production
}));

app.get('/api/user', (req, res) => {
  // This is a placeholder. You should implement your own authentication logic here.
  res.status(401).json({ error: 'Not authenticated' });
});

const PORT = process.env.SERVER_PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});