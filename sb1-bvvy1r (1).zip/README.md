# Responsive Dashboard

...

## Webhook Integration

This project includes a webhook endpoint that receives notifications from Railway about deployments and other events. The webhook is already set up in the Railway dashboard with the following configuration:

- Webhook URL: `https://${RAILWAY_PRIVATE_DOMAIN}/api/railway-webhook`
- Events: Deployment Succeeded, Deployment Failed (and any other events you've selected)

The webhook endpoint will log received events and Railway environment variables to the console. You can extend the functionality in `src/server/webhook.ts` to handle events as needed for your project.

To view webhook logs:
1. Go to your Railway dashboard
2. Navigate to your project
3. Click on the "Deployments" tab
4. Look for the "Webhooks" section to see recent webhook events and their status

...