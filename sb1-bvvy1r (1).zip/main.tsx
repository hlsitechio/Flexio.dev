import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/global.css';

// Helper function to safely get the root element
const getRootElement = (id: string): HTMLElement => {
  const element = document.getElementById(id);
  if (!element) {
    throw new Error(`Root element with id "${id}" not found. Ensure your HTML file has a matching element.`);
  }
  return element;
};

// Create a root using ReactDOM
const rootElement = getRootElement('root');
const root = ReactDOM.createRoot(rootElement);

// Function to render the app
const renderApp = () => {
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  );
};

// Initial render
renderApp();

// Optional: Enable Hot Module Replacement (HMR) in development
if (import.meta.hot) {
  import.meta.hot.accept('./App', () => {
    console.log('Hot module replacement triggered for App component.');
    renderApp();
  });
}

// Optional: Log environment info (only in development mode)
if (process.env.NODE_ENV === 'development') {
  console.info('Running in development mode');
}
